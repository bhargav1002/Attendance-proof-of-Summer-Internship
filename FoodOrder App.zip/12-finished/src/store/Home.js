import React,{useState} from 'react'
import CartProvider from './CartProvider'
import Cart from  '../components/Cart/Cart';
import Header from '../components/Layout/Header';
import Meals from '../components/Meals/Meals';

export default function Home(props) {
    const [cartIsShown, setCartIsShown] = useState(false);

    const showCartHandler = () => {
        setCartIsShown(true);
    };

    const hideCartHandler = () => {
        setCartIsShown(false);
    };

    const logout = () =>
    {
        props.onLogout();
    }

  return (
      <CartProvider>
          {cartIsShown && <Cart onClose={hideCartHandler} />}
          <Header onShowCart={showCartHandler} log={logout}/>
          <main>
              <Meals />
          </main>
      </CartProvider>
  )
}
