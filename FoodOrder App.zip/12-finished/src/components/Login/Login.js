import React, {useState} from 'react';
import classes from '../Layout/Header.module.css';
import { Link } from 'react-router-dom';
import mealsImage from './meals.jpg';
import Card from '../UI/Card';
import c1 from '../Meals/AvailableMeals.module.css';

export default function Login(props) {

    const [enteredEmail, setEnteredEmail] = useState('');
    const [emailIsValid, setEmailIsValid] = useState();
    const [enteredPassword, setEnteredPassword] = useState('');
    const [passwordIsValid, setPasswordIsValid] = useState();
    const [formIsValid, setFormIsValid] = useState(false);

    const emailChangeHandler = (event) => {
        setEnteredEmail(event.target.value);

        setFormIsValid(
            event.target.value.includes('@') && enteredPassword.trim().length > 6
        );
    };

    const passwordChangeHandler = (event) => {
        setEnteredPassword(event.target.value);

        setFormIsValid(
            event.target.value.trim().length > 6 && enteredEmail.includes('@')
        );
    };

    const validateEmailHandler = () => {
        setEmailIsValid(enteredEmail.includes('@'));
    };

    const validatePasswordHandler = () => {
        setPasswordIsValid(enteredPassword.trim().length > 6);
    };

    const submitHandler = (event) => {
        event.preventDefault();
        props.onLogin(enteredEmail, enteredPassword);
        console.log(10);
    };

    return (
        <div>
            <header className={classes.header}>
                <h1>ReactMeals</h1>
            </header>
            <div className={classes['main-image']}>
                <img src={mealsImage} alt='A table full of delicious food!' />
            </div>

            <section className={c1.meals}>
                <Card>
                    <form className='px-5' onSubmit={submitHandler}>

                        <h2 className='text-center'>Login</h2>

                        <div className="mb-3">
                            <label htmlFor="exampleFormControlInput1" className="form-label">Email address</label>
                            <input type="email" className="form-control" id="exampleFormControlInput1" value={enteredEmail}
                                onChange={emailChangeHandler} onBlur={validateEmailHandler} />
                        </div>
                        <div className="mb-3">
                            <label htmlFor="exampleFormControlInput2" className="form-label">Password</label>
                            <input type="password" className="form-control" id="exampleFormControlInput2" onChange={passwordChangeHandler}
                                onBlur={validatePasswordHandler} />
                        </div>

                        <button className="btn btn-primary">Submit</button>
                    </form>
                </Card>
            </section>



        </div>
    )
}
