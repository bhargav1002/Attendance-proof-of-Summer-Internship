import React, {useState} from 'react';
import classes from '../Layout/Header.module.css';
import { Link } from 'react-router-dom';
import mealsImage from './meals.jpg';
import Card from '../UI/Card';
import c1 from '../Meals/AvailableMeals.module.css';
import './login.css';
import toastr from 'toastr'
import 'toastr/build/toastr.min.css';

export default function Login(props) {

    const [enteredEmail, setEnteredEmail] = useState('');
    const [emailIsValid, setEmailIsValid] = useState();
    const [enteredPassword, setEnteredPassword] = useState('');
    const [passwordIsValid, setPasswordIsValid] = useState();
    const [formIsValid, setFormIsValid] = useState(false);

    const emailChangeHandler = (event) => {
        setEnteredEmail(event.target.value);

        setFormIsValid(
            event.target.value.includes('@') && enteredPassword.trim().length > 6
        );
        console.log("a",formIsValid);

    };

    const passwordChangeHandler = (event) => {
        setEnteredPassword(event.target.value);

        setFormIsValid(
            event.target.value.trim().length > 6 && enteredEmail.includes('@')
        );
        console.log("b",formIsValid);
    };

    const validateEmailHandler = () => {
        setEmailIsValid(enteredEmail.includes('@'));
    };

    const validatePasswordHandler = () => {
        setPasswordIsValid(enteredPassword.trim().length > 6);
    };

    const submitHandler = (event) => {
        event.preventDefault();
        if(!formIsValid)
        {
            toastr.options = {
                "closeButton": true,
                "newestOnTop": false,
                "progressBar": false,
                "positionClass": "toast-bottom-right",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "300",
                "hideDuration": "1000",
                "timeOut": "5000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
            }
            toastr.clear();
            setTimeout(() => toastr.error(`Enter Proper Username or Password`), 300);
            return;
        }
        props.onLogin(enteredEmail, enteredPassword);
    };


    const style = {
        
    }

    return (
        <div>
            <header className={classes.header}>
                <h1>ReactMeals</h1>
            </header>
            <div className={classes['main-image']}>
                <img src={mealsImage} alt='A table full of delicious food!' />
            </div>

            <section className={c1.meals} style={{ maxWidth: '45rem', margin: '-15rem auto'}}>
                <Card style={{zIndex:100}}>
                    <form className='px-5' onSubmit={submitHandler}>

                        <h2 className='text-center'>Login</h2>
                        <br></br>
                        <div className="mb-3 ">
                            <label htmlFor="exampleFormControlInput1" className="form-label">Email address</label>
                            <input type="email" className="form-control" id="exampleFormControlInput1"  value={enteredEmail}
                                onChange={emailChangeHandler} onBlur={validateEmailHandler} />
                        </div>
                        <br></br>
                        <div className="mb-3 ">
                            <label htmlFor="exampleFormControlInput2" className="form-label">Password</label>
                            <input type="password" className="form-control" id="exampleFormControlInput2" onChange={passwordChangeHandler}
                                onBlur={validatePasswordHandler} />
                        </div>
                        <br></br>
                        <div className='d-flex justify-content-center'>
                            <button className="btn rounded-pill px-4 py-2 myprimary">Login</button>
                        </div>
                    </form>
                </Card>
            </section>



        </div>
    )
}
