import Home from './store/Home';
import Login from './components/Login/Login';
import React, {useState,useEffect} from 'react';

function App() {

  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    const storedUserLoggedInInformation = localStorage.getItem('isLoggedIn');

    if (storedUserLoggedInInformation === '1') {
      setIsLoggedIn(true);
    }
  }, []);

  const loginHandler = (email, password) => {
    localStorage.setItem('isLoggedIn', '1');
    setIsLoggedIn(true);
    console.log("f",isLoggedIn);
  };

  const logoutHandler = () => {
    localStorage.removeItem('isLoggedIn');
    setIsLoggedIn(false);
  };

  return (
    <>
      {isLoggedIn && <Home onLogout={logoutHandler} />}
      {!isLoggedIn && <Login onLogin={loginHandler} />}
    </>
  );
}

export default App;
