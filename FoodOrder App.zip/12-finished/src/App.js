import { BrowserRouter,Route,Routes } from 'react-router-dom';
import Home from './store/Home';
import Login from './components/Login/Login';
import React, {useState,useEffect} from 'react';


function App() {

  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    const storedUserLoggedInInformation = localStorage.getItem('isLoggedIn');

    if (storedUserLoggedInInformation === '1') {
      setIsLoggedIn(true);
    }
  }, []);

  const loginHandler = (email, password) => {
    // We should of course check email and password
    // But it's just a dummy/ demo anyways
    localStorage.setItem('isLoggedIn', '1');
    setIsLoggedIn(true);
    console.log(setIsLoggedIn);
  };

  const logoutHandler = () => {
    localStorage.removeItem('isLoggedIn');
    setIsLoggedIn(false);
  };

  return (
    <>
      {!isLoggedIn && <Login onLogin={loginHandler} />}
      {isLoggedIn && <Home/>}
    </>
  );
}

export default App;


{/* <BrowserRouter>
  <div className="App">
    <Routes>
      <Route exact path='/' Component={Login} />
      <Route path='/Home' Component={Home} />
    </Routes>
  </div>
</BrowserRouter> */}